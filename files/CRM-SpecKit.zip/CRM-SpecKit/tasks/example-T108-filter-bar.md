# مثال تطبيقي مُعبَّأ — T108 (إصلاح B4: الفلاتر لا تعمل)

هذا مثال حقيقي مملوء بالكامل يوضح كيفية استخدام `_template-prompt.md` — استخدمه كمرجع عند تعبئة القوالب الأخرى.

```
أنت مطوّر Front-End تعمل ضمن مشروع CRM. اتبع القواعد التالية بصرامة تامة، بدون أي استثناء:

=== القيود الثابتة ===
- Vanilla JS فقط (ES Modules)، لا أطر خارجية.
- كل وصول للبيانات عبر js/data/store.js فقط.
- معرّفات DOM بصيغة kebab-case مسبوقة بـ prefix الصفحة (مثل leads-filter-stage).
- أي افتراض غير محدد يُكتب كتعليق // ASSUMPTION:

=== سياق المشروع ===
توقيع الدالة العامة في store.js:
export async function query(entity, filterFn) // تعيد مصفوفة سجلات تطابق filterFn

القوائم الثابتة متوفرة في js/data/constants.js: STAGES, RATINGS, SOURCES, AGENTS

=== المهمة الحالية ===
معرّف المهمة: T108
الوصف: بناء js/components/filter-bar.js يحتوي: بحث نصي (name/phone) + فلاتر
stage/rating/source/assignedTo، وربط زر "تطبيق" فعليًا بحيث يستدعي دالة
applyFilters() التي تُعيد بيانات مفلترة فعليًا من store.query('leads', ...)
وتُحدّث جدول data-table.js المعروض. هذا يُصلح المشكلة المعروفة B4: "الفلاتر
حاليًا لا تُنفّذ أي شيء عند اختيار قيمة والضغط على تطبيق".
الملفات المطلوبة: js/components/filter-bar.js فقط (لا تعدّل ملفات أخرى).
التبعيات المكتملة: data-table.js (T104)، leads.js يستورد filter-bar ويمرر له
callback اسمه onApply(filteredLeads).

=== معايير القبول ===
- تغيير قيمة rating إلى "Cold" ثم الضغط على زر "تطبيق" يجب أن يُنتج فعليًا
  استدعاءً لـ onApply() بمصفوفة تحتوي فقط سجلات rating === 'Cold'.
- عدم اختيار أي فلتر (كل الحقول فارغة) + "تطبيق" يعيد كل السجلات دون فلترة.
- اختيار أكثر من فلتر معًا (rating + stage) يُطبَّق كشرط AND (تقاطع، وليس اتحاد).
- زر "تطبيق" مربوط عبر addEventListener('click', ...) فعليًا، وليس دالة فارغة
  أو placeholder.

=== تعليمات الإخراج ===
أعد محتوى js/components/filter-bar.js كاملًا فقط.
```

**النتيجة المتوقعة من نموذج رخيص جيد**: ملف JS واحد يُصدّر دالة `initFilterBar(container, onApply)` تبني عناصر الفلترة من `constants.js`، وتربط الزر بدالة `applyFilters()` تستدعي `store.query('leads', lead => ...)` بشرط AND حقيقي، ثم `onApply(result)`.
